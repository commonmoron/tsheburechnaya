#include <stdio.h>

#define SIZE 10

int read_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        if (scanf("%d", &arr[i]) != 1) return 0;
    }
    return 1;
}

void sort_array(int *arr, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
            }
        }
    }
}

void print_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        printf("%d", arr[i]);
        if (i != size - 1) printf(" ");
    }
}

int main() {
    int arr[SIZE];
    if (!read_array(arr, SIZE)) {
        printf("n/a");
        return 1;
    }
    sort_array(arr, SIZE);
    print_array(arr, SIZE);
    return 0;
}
