#include <stdio.h>

void input_array(int *a, int n) {
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
}

int sum_even(int *a, int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0 && a[i] != 0) {
            sum += a[i];
        }
    }
    return sum;
}

void process_array(int *a, int n, int sum, int *result, int *result_size) {
    *result_size = 0;
    if (sum == 0) return;

    for (int i = 0; i < n; i++) {
        if (a[i] != 0 && sum % a[i] == 0) {
            result[*result_size] = a[i];
            (*result_size)++;
        }
    }
}

void output_array(int *a, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d", a[i]);
        if (i < n - 1) {
            printf(" ");
        }
    }
    printf("\n");
}

int main() {
    int n;
    scanf("%d", &n);

    if (n <= 0 || n > 10) {
        printf("n/a\n");
        return 0;
    }

    int array[10];
    input_array(array, n);

    int sum = sum_even(array, n);
    if (sum == 0) {
        printf("n/a\n");
        return 0;
    }

    int result[10];
    int result_size;
    process_array(array, n, sum, result, &result_size);

    if (result_size == 0) {
        printf("n/a\n");
        return 0;
    }

    printf("%d\n", sum);
    output_array(result, result_size);

    return 0;
}
