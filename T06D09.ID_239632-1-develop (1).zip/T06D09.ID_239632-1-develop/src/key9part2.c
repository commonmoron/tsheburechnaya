#include <stdio.h>

void add_numbers(const int *a, int a_len, const int *b, int b_len, int *result, int *result_len) {
    int max_len = a_len > b_len ? a_len : b_len;
    int carry = 0;
    *result_len = 0;

    for (int i = 0; i < max_len || carry; i++) {
        int digit_a = i < a_len ? a[a_len - 1 - i] : 0;
        int digit_b = i < b_len ? b[b_len - 1 - i] : 0;
        int sum = digit_a + digit_b + carry;
        result[max_len - i] = sum % 10;
        carry = sum / 10;
        (*result_len)++;
    }

    if (carry) {
        result[0] = carry;
        (*result_len)++;
    } else {
        for (int i = 0; i < *result_len; i++) {
            result[i] = result[i + 1];
        }
    }
}

int compare_numbers(const int *a, int a_len, const int *b, int b_len) {
    if (a_len != b_len) return a_len - b_len;
    for (int i = 0; i < a_len; i++) {
        if (a[i] != b[i]) return a[i] - b[i];
    }
    return 0;
}

void subtract_numbers(const int *a, int a_len, const int *b, int b_len, int *result, int *result_len) {
    if (compare_numbers(a, a_len, b, b_len) < 0) {
        *result_len = -1;
        return;
    }

    int borrow = 0;
    *result_len = a_len;

    for (int i = 0; i < a_len; i++) {
        int digit_a = a[a_len - 1 - i];
        int digit_b = i < b_len ? b[b_len - 1 - i] : 0;
        int diff = digit_a - digit_b - borrow;

        if (diff < 0) {
            diff += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }

        result[a_len - 1 - i] = diff;
    }

    while (*result_len > 1 && result[0] == 0) {
        for (int i = 0; i < *result_len - 1; i++) {
            result[i] = result[i + 1];
        }
        (*result_len)--;
    }
}

void print_number(const int *num, int len) {
    for (int i = 0; i < len; i++) {
        printf("%d", num[i]);
        if (i < len - 1) printf(" ");
    }
    printf("\n");
}

int read_number(int *num) {
    int len = 0;
    char c;

    while (1) {
        if (scanf("%d%c", &num[len], &c) != 2) return -1;
        len++;
        if (c == '\n') break;
        if (len >= 100) return -1;
    }

    return len;
}

int main() {
    int a[100], b[100];
    int a_len, b_len;

    a_len = read_number(a);
    if (a_len == -1) {
        printf("n/a\n");
        return 0;
    }

    b_len = read_number(b);
    if (b_len == -1) {
        printf("n/a\n");
        return 0;
    }

    int sum[101], sum_len;
    add_numbers(a, a_len, b, b_len, sum, &sum_len);
    print_number(sum, sum_len);

    int diff[100], diff_len;
    subtract_numbers(a, a_len, b, b_len, diff, &diff_len);

    if (diff_len == -1) {
        printf("n/a\n");
    } else {
        print_number(diff, diff_len);
    }

    return 0;
}
