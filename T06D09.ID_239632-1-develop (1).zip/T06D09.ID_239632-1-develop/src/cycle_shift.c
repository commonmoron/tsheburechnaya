#include <stdio.h>

void shift_left(int *array, int n, int c) {
    c = c % n;
    if (c < 0) c += n;
    int temp[c];
    for (int i = 0; i < c; i++) {
        temp[i] = array[i];
    }
    for (int i = 0; i < n - c; i++) {
        array[i] = array[i + c];
    }
    for (int i = 0; i < c; i++) {
        array[n - c + i] = temp[i];
    }
}

void shift_right(int *array, int n, int c) {
    c = -c;
    c = c % n;
    if (c < 0) c += n;
    int temp[c];
    for (int i = 0; i < c; i++) {
        temp[i] = array[n - c + i];
    }
    for (int i = n - 1; i >= c; i--) {
        array[i] = array[i - c];
    }
    for (int i = 0; i < c; i++) {
        array[i] = temp[i];
    }
}

void print_array(int *array, int n) {
    for (int i = 0; i < n; i++) {
        if (i != 0) printf(" ");
        printf("%d", array[i]);
    }
    printf("\n");
}

int main() {
    int n, c;
    if (scanf("%d", &n) != 1 || n <= 0 || n > 10) {
        printf("n/a\n");
        return 0;
    }
    int array[n];
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &array[i]) != 1) {
            printf("n/a\n");
            return 0;
        }
    }
    if (scanf("%d", &c) != 1) {
        printf("n/a\n");
        return 0;
    }
    if (c > 0) {
        shift_left(array, n, c);
    } else if (c < 0) {
        shift_right(array, n, c);
    }
    print_array(array, n);
    return 0;
}
