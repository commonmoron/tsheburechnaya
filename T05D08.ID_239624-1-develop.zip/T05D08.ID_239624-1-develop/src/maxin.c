#include <stdio.h>

int input(int *a, int *b, int *c) { return scanf("%d %d %d", a, b, c) == 3; }

void maxmin(int a, int b, int c, int *max, int *min) {
    *max = a;
    *min = a;
    if (b > *max) *max = b;
    if (c > *max) *max = c;
    if (b < *min) *min = b;
    if (c < *min) *min = c;
}

int main() {
    int a, b, c;
    if (!input(&a, &b, &c)) {
        printf("n/a\n");
        return 1;
    }

    int max, min;
    maxmin(a, b, c, &max, &min);
    printf("%d %d\n", max, min);

    return 0;
}
