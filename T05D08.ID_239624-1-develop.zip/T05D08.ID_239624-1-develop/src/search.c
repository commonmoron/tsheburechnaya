#include <math.h>
#include <stdio.h>

#define NMAX 30

int input(int *a, int *n) {
    if (scanf("%d", n) != 1 || *n <= 0 || *n > NMAX) return 1;
    for (int i = 0; i < *n; i++)
        if (scanf("%d", &a[i]) != 1) return 1;
    return 0;
}

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("n/a\n");
        return 0;
    }
    double mean_v = 0, sum = 0, variance_v = 0;
    for (int i = 0; i < n; i++) {
        sum += data[i];
    }
    mean_v = sum / n;
    for (int i = 0; i < n; i++) {
        variance_v += (data[i] - mean_v) * (data[i] - mean_v);
    }
    variance_v /= n;

    double upper_limit = mean_v + 3 * sqrt(variance_v);
    for (int i = 0; i < n; i++) {
        if (data[i] % 2 == 0 && data[i] >= mean_v && data[i] <= upper_limit && data[i] != 0) {
            printf("%d\n", data[i]);
            return 0;
        }
    }
    printf("0\n");
    return 0;
}
