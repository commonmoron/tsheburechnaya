#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void free_matrix(double **matrix, int size) {
    for (int i = 0; i < size; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

double **create_matrix(int size) {
    double **matrix = (double **)malloc(size * sizeof(double *));
    if (!matrix) return NULL;

    for (int i = 0; i < size; i++) {
        matrix[i] = (double *)malloc(size * sizeof(double));
        if (!matrix[i]) {
            free_matrix(matrix, i);
            return NULL;
        }
    }
    return matrix;
}

int copy_matrix(double **src, double **dest, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            dest[i][j] = src[i][j];
        }
    }
    return 1;
}

int gauss_jordan(double **matrix, double **inverse, int size) {
    for (int i = 0; i < size; i++) {
        if (matrix[i][i] == 0.0) {
            int swap_row = -1;
            for (int k = i + 1; k < size; k++) {
                if (matrix[k][i] != 0.0) {
                    swap_row = k;
                    break;
                }
            }
            if (swap_row == -1) return 0;

            double *temp = matrix[i];
            matrix[i] = matrix[swap_row];
            matrix[swap_row] = temp;

            temp = inverse[i];
            inverse[i] = inverse[swap_row];
            inverse[swap_row] = temp;
        }

        double pivot = matrix[i][i];
        for (int j = 0; j < size; j++) {
            matrix[i][j] /= pivot;
            inverse[i][j] /= pivot;
        }

        for (int k = 0; k < size; k++) {
            if (k != i && matrix[k][i] != 0.0) {
                double factor = matrix[k][i];
                for (int j = 0; j < size; j++) {
                    matrix[k][j] -= matrix[i][j] * factor;
                    inverse[k][j] -= inverse[i][j] * factor;
                }
            }
        }
    }
    return 1;
}

int parse_number(char *token) {
    char *comma = strchr(token, ',');
    if (comma) *comma = '.';
    return 1;
}

int main() {
    int size;
    if (scanf("%d %d", &size, &size) != 2 || size <= 0) {
        printf("n/a");
        return 0;
    }

    double **matrix = create_matrix(size);
    double **inverse = create_matrix(size);
    if (!matrix || !inverse) {
        printf("n/a");
        if (matrix) free_matrix(matrix, size);
        if (inverse) free_matrix(inverse, size);
        return 0;
    }

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            char num_str[20];
            if (scanf("%19s", num_str) != 1) {
                free_matrix(matrix, size);
                free_matrix(inverse, size);
                printf("n/a");
                return 0;
            }
            parse_number(num_str);
            if (sscanf(num_str, "%lf", &matrix[i][j]) != 1) {
                free_matrix(matrix, size);
                free_matrix(inverse, size);
                printf("n/a");
                return 0;
            }
            inverse[i][j] = (i == j) ? 1.0 : 0.0;
        }
    }

    double **temp_matrix = create_matrix(size);
    if (!temp_matrix) {
        free_matrix(matrix, size);
        free_matrix(inverse, size);
        printf("n/a");
        return 0;
    }
    copy_matrix(matrix, temp_matrix, size);

    if (!gauss_jordan(temp_matrix, inverse, size)) {
        free_matrix(matrix, size);
        free_matrix(inverse, size);
        free_matrix(temp_matrix, size);
        printf("n/a");
        return 0;
    }

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            printf("%.6lf", inverse[i][j]);
            if (j < size - 1) printf(" ");
        }
        if (i < size - 1) printf("\n");
    }

    free_matrix(matrix, size);
    free_matrix(inverse, size);
    free_matrix(temp_matrix, size);

    return 0;
}
