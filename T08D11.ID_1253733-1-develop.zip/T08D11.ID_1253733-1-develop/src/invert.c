#include <math.h>
#include <stdio.h>
#include <stdlib.h>

void print_matrix(double **matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%.6lf", matrix[i][j]);
            if (j != n - 1) printf(" ");
        }
        if (i != n - 1) printf("\n");
    }
}

void free_matrix(double **matrix, int n) {
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

double **create_matrix(int n) {
    double **matrix = (double **)malloc(n * sizeof(double *));
    for (int i = 0; i < n; i++) {
        matrix[i] = (double *)malloc(n * sizeof(double));
    }
    return matrix;
}

void copy_matrix(double **src, double **dest, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dest[i][j] = src[i][j];
        }
    }
}

int invert_matrix(double **matrix, int n) {
    double **inverse = create_matrix(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            inverse[i][j] = (i == j) ? 1.0 : 0.0;
        }
    }

    for (int col = 0; col < n; col++) {
        int pivot = col;
        for (int row = col + 1; row < n; row++) {
            if (fabs(matrix[row][col]) > fabs(matrix[pivot][col])) {
                pivot = row;
            }
        }

        if (matrix[pivot][col] == 0.0) {
            free_matrix(inverse, n);
            return 0;
        }

        if (pivot != col) {
            double *temp = matrix[col];
            matrix[col] = matrix[pivot];
            matrix[pivot] = temp;

            temp = inverse[col];
            inverse[col] = inverse[pivot];
            inverse[pivot] = temp;
        }

        double div = matrix[col][col];
        for (int j = 0; j < n; j++) {
            matrix[col][j] /= div;
            inverse[col][j] /= div;
        }

        for (int row = 0; row < n; row++) {
            if (row != col && matrix[row][col] != 0.0) {
                double factor = matrix[row][col];
                for (int j = 0; j < n; j++) {
                    matrix[row][j] -= matrix[col][j] * factor;
                    inverse[row][j] -= inverse[col][j] * factor;
                }
            }
        }
    }

    copy_matrix(inverse, matrix, n);
    free_matrix(inverse, n);
    return 1;
}

int main() {
    int n, m;
    if (scanf("%d %d", &n, &m) != 2 || n != m) {
        printf("n/a");
        return 0;
    }

    double **matrix = create_matrix(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (scanf("%lf", &matrix[i][j]) != 1) {
                free_matrix(matrix, n);
                printf("n/a");
                return 0;
            }
        }
    }

    double **original = create_matrix(n);
    copy_matrix(matrix, original, n);

    if (!invert_matrix(matrix, n)) {
        free_matrix(matrix, n);
        free_matrix(original, n);
        printf("n/a");
        return 0;
    }

    print_matrix(matrix, n);

    free_matrix(matrix, n);
    free_matrix(original, n);
    return 0;
}
