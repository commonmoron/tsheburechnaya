#include "parse_expression.h"

int is_operator(char c) { return c == '+' || c == '-' || c == '*' || c == '/'; }

int my_isdigit(char c) { return (c >= '0' && c <= '9'); }

int my_isalpha(char c) { return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')); }

void processing_numbers(const char *expression, Token **tokens, int *num_tokens, int *i) {
    int j = 0;

    char num[50] = {'\0'};
    while (my_isdigit(expression[*i]) || expression[*i] == '.') {
        num[j++] = expression[*i];
        *i = *i + 1;
    }
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    (*tokens)[(*num_tokens) - 1].type = TOKEN_NUMBER;
    strcpy((*tokens)[(*num_tokens) - 1].value, num);
}

void unary_minus(Token **tokens, int *num_tokens, int *i) {
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    (*tokens)[(*num_tokens) - 1].type = TOKEN_OPERATOR;
    (*tokens)[(*num_tokens) - 1].value[0] = '#';
    (*tokens)[(*num_tokens) - 1].value[1] = '\0';
    *i = *i + 1;
}

void processing_operators(const char *expression, Token **tokens, int *num_tokens, int *i) {
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    (*tokens)[(*num_tokens) - 1].type = TOKEN_OPERATOR;
    (*tokens)[(*num_tokens) - 1].value[0] = expression[*i];
    (*tokens)[(*num_tokens) - 1].value[1] = '\0';
    *i = *i + 1;
}

void processing_the_left_bracket(Token **tokens, int *num_tokens, int *i) {
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    (*tokens)[(*num_tokens) - 1].type = TOKEN_LEFT_PAREN;
    (*tokens)[(*num_tokens) - 1].value[0] = '(';
    (*tokens)[(*num_tokens) - 1].value[1] = '\0';
    *i = *i + 1;
}

void processing_the_right_bracket(Token **tokens, int *num_tokens, int *i) {
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    (*tokens)[(*num_tokens) - 1].type = TOKEN_RIGHT_PAREN;
    (*tokens)[(*num_tokens) - 1].value[0] = ')';
    (*tokens)[(*num_tokens) - 1].value[1] = '\0';
    *i = *i + 1;
}

void processing_functions_or_variables(const char *expression, Token **tokens, int *num_tokens, int *i) {
    int j = 0;

    char identifier[50] = {'\0'};
    while (my_isalpha(expression[*i])) {
        identifier[j++] = expression[*i];
        *i = *i + 1;
    }
    (*num_tokens)++;
    *tokens = (Token *)realloc(*tokens, sizeof(Token) * (*num_tokens));
    if (strcmp(identifier, "sin") == 0 || strcmp(identifier, "cos") == 0 || strcmp(identifier, "tan") == 0 ||
        strcmp(identifier, "ctg") == 0 || strcmp(identifier, "sqrt") == 0 || strcmp(identifier, "ln") == 0) {
        (*tokens)[(*num_tokens) - 1].type = TOKEN_FUNCTION;
    } else {
        (*tokens)[(*num_tokens) - 1].type = TOKEN_VARIABLE;
    }
    strcpy((*tokens)[(*num_tokens) - 1].value, identifier);
}

void parse_expression(const char *expression, Token **tokens, int *num_tokens) {
    *num_tokens = 0;
    *tokens = NULL;
    int i = 0;
    while (expression[i] != '\0') {
        if (expression[i] == ' ') {
            i++;
            continue;
        }
        if (my_isdigit(expression[i])) {
            processing_numbers(expression, tokens, num_tokens, &i);
        } else if (expression[i] == '-' && expression[i - 1] != ')' &&
                   (i == 0 || expression[i - 1] != my_isdigit(expression[i - 1]))) {
            unary_minus(tokens, num_tokens, &i);
        } else if (is_operator(expression[i])) {
            processing_operators(expression, tokens, num_tokens, &i);
        } else if (expression[i] == '(') {
            processing_the_left_bracket(tokens, num_tokens, &i);
        } else if (expression[i] == ')') {
            processing_the_right_bracket(tokens, num_tokens, &i);
        } else if (my_isalpha(expression[i])) {
            processing_functions_or_variables(expression, tokens, num_tokens, &i);
        } else {
            i++;
        }
    }
}
