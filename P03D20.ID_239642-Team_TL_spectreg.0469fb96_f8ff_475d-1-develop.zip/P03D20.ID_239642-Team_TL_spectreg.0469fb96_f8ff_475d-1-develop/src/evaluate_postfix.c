#include "evaluate_postfix.h"

char *ftos(double num) {
    char *str = (char *)malloc(20);
    snprintf(str, 20, "%lf", num);
    return str;
}

void function_variable(const Token *current_token, Stack *operand_stack, double x) {
    if (current_token->value[0] == '-') {
        char *ccc = ftos(-x);
        stack_push(operand_stack, ccc);
        free(ccc);
    } else {
        char *ccc = ftos(x);
        stack_push(operand_stack, ccc);
        free(ccc);
    }
}

void function_operator(const Token *current_token, Stack *operand_stack) {
    double operand2 = atof(stack_top(operand_stack));
    char *o1 = stack_pop(operand_stack);
    free(o1);
    double operand1 = atof(stack_top(operand_stack));
    char *o2 = stack_pop(operand_stack);
    free(o2);

    if (strcmp(current_token->value, "+") == 0) {
        char *ccc = ftos(operand1 + operand2);
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "-") == 0) {
        char *ccc = ftos(operand1 - operand2);
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "*") == 0) {
        char *ccc = ftos(operand1 * operand2);
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "/") == 0) {
        char *ccc = ftos(operand1 / operand2);
        stack_push(operand_stack, ccc);
        free(ccc);
    }
}

void function_function(const Token *current_token, Stack *operand_stack) {
    double operand = atof(stack_top(operand_stack));
    char *c = stack_pop(operand_stack);
    free(c);

    if (strcmp(current_token->value, "sin") == 0) {
        char *ccc = ftos(sin(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "cos") == 0) {
        char *ccc = ftos(cos(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "tan") == 0) {
        char *ccc = ftos(tan(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "ctg") == 0) {
        char *ccc = ftos(1.0 / tan(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "sqrt") == 0) {
        char *ccc = ftos(sqrt(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    } else if (strcmp(current_token->value, "ln") == 0) {
        char *ccc = ftos(log(operand));
        stack_push(operand_stack, ccc);
        free(ccc);
    }
}

double evaluate_postfix(const Token *postfix_tokens, int num_postfix_tokens, double x) {
    Stack operand_stack;
    stack_init(&operand_stack, num_postfix_tokens);

    for (int i = 0; i < num_postfix_tokens; i++) {
        const Token *current_token = &postfix_tokens[i];
        if (current_token->type == TOKEN_NUMBER) {
            stack_push(&operand_stack, current_token->value);
        } else if (current_token->type == TOKEN_VARIABLE) {
            function_variable(current_token, &operand_stack, x);
        } else if (current_token->type == TOKEN_OPERATOR) {
            function_operator(current_token, &operand_stack);
        } else if (current_token->type == TOKEN_FUNCTION) {
            function_function(current_token, &operand_stack);
        }
    }

    double result = atof(stack_top(&operand_stack));
    char *c = stack_pop(&operand_stack);
    free(c);

    stack_free(&operand_stack);
    return result;
}

double evaluate_postfix_function(const Token *postfix_tokens, int num_postfix_tokens, double x) {
    return evaluate_postfix(postfix_tokens, num_postfix_tokens, x);
}
