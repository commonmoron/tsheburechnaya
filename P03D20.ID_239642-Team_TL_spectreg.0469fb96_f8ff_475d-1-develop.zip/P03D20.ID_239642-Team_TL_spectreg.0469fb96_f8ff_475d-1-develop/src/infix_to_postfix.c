#include "infix_to_postfix.h"

int precedence(const char *operator) {
    int priority = 0;
    if (strcmp(operator, "+") == 0 || strcmp(operator, "-") == 0) {
        priority = 1;
    } else if (strcmp(operator, "*") == 0 || strcmp(operator, "/") == 0) {
        priority = 2;
    } else if (strcmp(operator, "sin") == 0 || strcmp(operator, "cos") == 0 || strcmp(operator, "tan") == 0 ||
               strcmp(operator, "ctg") == 0 || strcmp(operator, "sqrt") == 0 || strcmp(operator, "ln") == 0) {
        priority = 2;
    }
    return priority;
}

void number_or_variable(Token **postfix_tokens, int *num_postfix_tokens, const Token *current_token) {
    (*num_postfix_tokens)++;
    *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
    (*postfix_tokens)[(*num_postfix_tokens) - 1] = *current_token;
}

void unary_minus_2(const Token *infix_tokens, Token **postfix_tokens, int *num_postfix_tokens, int *i) {
    const Token *next_token = &infix_tokens[*i + 1];
    if (next_token->type == TOKEN_LEFT_PAREN && infix_tokens[*i + 2].value[0] == '#') {
        *i = *i + 2;
    } else if (next_token->type == TOKEN_LEFT_PAREN &&
               (infix_tokens[*i + 2].type == TOKEN_NUMBER || infix_tokens[*i + 2].type == TOKEN_VARIABLE)) {
        char new_value[50];
        new_value[0] = '-';
        for (int j = 1; infix_tokens[*i + 2].value[j - 1] != '\0'; j++) {
            new_value[j] = infix_tokens[*i + 2].value[j - 1];
            if (infix_tokens[*i + 2].value[j - 1] == '\0') {
                new_value[j + 1] = '\0';
            }
        }

        (*num_postfix_tokens)++;
        *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
        (*postfix_tokens)[(*num_postfix_tokens) - 1].type = infix_tokens[*i + 2].type;
        strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, new_value);
        *i = *i + 2;
    } else if (next_token->value[0] == '#') {
        *i = *i + 1;
    }
    if (next_token->type == TOKEN_NUMBER || next_token->type == TOKEN_VARIABLE) {
        char new_value[50];
        new_value[0] = '-';
        for (int j = 1; next_token->value[j - 1] != '\0'; j++) {
            new_value[j] = next_token->value[j - 1];
            if (next_token->value[j - 1] == '\0') {
                new_value[j + 1] = '\0';
            }
        }

        (*num_postfix_tokens)++;
        *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
        (*postfix_tokens)[(*num_postfix_tokens) - 1].type = next_token->type;
        strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, new_value);
        *i = *i + 1;
    }
}

void non_unary_minus(Stack *operator_stack, Token **postfix_tokens, int *num_postfix_tokens,
                     const Token *current_token) {
    while (!stack_empty(operator_stack) &&
           precedence(stack_top(operator_stack)) >= precedence(current_token->value) &&
           strcmp(stack_top(operator_stack), "(") != 0) {
        char *operator= stack_pop(operator_stack);
        (*num_postfix_tokens)++;
        *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
        (*postfix_tokens)[(*num_postfix_tokens) - 1].type = TOKEN_OPERATOR;
        strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, operator);
        free(operator);
    }

    stack_push(operator_stack, current_token->value);
}

void right_bracket(Stack *operator_stack, Token **postfix_tokens, int *num_postfix_tokens) {
    while (!stack_empty(operator_stack) && strcmp(stack_top(operator_stack), "(") != 0) {
        char *operator= stack_pop(operator_stack);
        (*num_postfix_tokens)++;
        *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
        (*postfix_tokens)[(*num_postfix_tokens) - 1].type = TOKEN_OPERATOR;
        strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, operator);
        free(operator);
    }

    char *operator= stack_pop(operator_stack);
    free(operator);
    if (!stack_empty(operator_stack) && stack_top(operator_stack)[0] != '(') {
        if (strcmp(stack_top(operator_stack), "sin") == 0 || strcmp(stack_top(operator_stack), "cos") == 0 ||
            strcmp(stack_top(operator_stack), "tan") == 0 || strcmp(stack_top(operator_stack), "ctg") == 0 ||
            strcmp(stack_top(operator_stack), "sqrt") == 0 || strcmp(stack_top(operator_stack), "ln") == 0) {
            char *function = stack_pop(operator_stack);
            (*num_postfix_tokens)++;
            *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
            (*postfix_tokens)[(*num_postfix_tokens) - 1].type = TOKEN_FUNCTION;
            strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, function);
            free(function);
        }
    }
}

void infix_to_postfix(const Token *infix_tokens, int num_infix_tokens, Token **postfix_tokens,
                      int *num_postfix_tokens) {
    *num_postfix_tokens = 0;
    *postfix_tokens = NULL;
    Stack operator_stack;
    stack_init(&operator_stack, num_infix_tokens);

    for (int i = 0; i < num_infix_tokens; i++) {
        const Token *current_token = &infix_tokens[i];
        if (current_token->type == TOKEN_NUMBER || current_token->type == TOKEN_VARIABLE) {
            number_or_variable(postfix_tokens, num_postfix_tokens, current_token);
        } else if (current_token->type == TOKEN_OPERATOR) {
            if (current_token->value[0] == '#') {
                unary_minus_2(infix_tokens, postfix_tokens, num_postfix_tokens, &i);
            } else {
                non_unary_minus(&operator_stack, postfix_tokens, num_postfix_tokens, current_token);
            }
        } else if (current_token->type == TOKEN_FUNCTION) {
            stack_push(&operator_stack, current_token->value);
        } else if (current_token->type == TOKEN_LEFT_PAREN) {
            stack_push(&operator_stack, current_token->value);
        } else if (current_token->type == TOKEN_RIGHT_PAREN) {
            right_bracket(&operator_stack, postfix_tokens, num_postfix_tokens);
        }
    }

    while (!stack_empty(&operator_stack)) {
        char *operator= stack_pop(&operator_stack);
        (*num_postfix_tokens)++;
        *postfix_tokens = (Token *)realloc(*postfix_tokens, sizeof(Token) * (*num_postfix_tokens));
        (*postfix_tokens)[(*num_postfix_tokens) - 1].type = TOKEN_OPERATOR;
        strcpy((*postfix_tokens)[(*num_postfix_tokens) - 1].value, operator);
        free(operator);
    }

    stack_free(&operator_stack);
}
