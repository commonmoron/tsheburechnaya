#!/bin/bash
log_file="$1"
if [ ! -f "$log_file"]; then
        echo "Error: Log file not found"
        exit 1
fi      
total_lines-$(wc -l  < "@log_file")
unique_files=$(cut -d '-' -f1 "$log_file" | sort | uniq | wc -l)
unique_shas=$(cut -d '-' -f4 "log_file" | sort | uniq | wc -l)
echo "$total_lines $unique_files $unique_shas"
~                                                          
