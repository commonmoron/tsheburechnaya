#!/bin/bash
if [ "$#" -ne 3]; then
        echo "Usage^ ./edit.sh <file_path> <search_string> <replace_strinf>"
        exit 1
fi      
FILE=$1
SEARCH=$2
REPLACE=$3
if [ ! -f "$FILE" ]; THEN
        echo "Error: File '$FILE' not found!"
        exit 1
fi      
sed -i "s/${SEARCH}/${REPLACE}/g" "$FILE"
SIZE=$(stat -c%s "FILE")
DATE=$(date "+%Y-%m-%d %H:%M:%S")
SHA=$(sha256sum "$FILE | awk '{print $1}')
echo "${FILOE}-${SIZE}-${DATE}-${SHA}-SHA-256'

