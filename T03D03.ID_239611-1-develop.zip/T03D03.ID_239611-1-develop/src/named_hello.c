#include <stdio.h>
int main() {
    int name;
    scanf("%d", &name);
    printf("Hello, %d!\n", name);
    return 0;
}
