#include <stdio.h>
#include <math.h>

int main() {
    double x;
    if (scanf("%lf", &x) != 1 || x == 0) {
        printf("n/a\n");
        return 0;
    }

    double y = 0;

    double term1 = 7e-3 * pow(x, 4);
    double term2 = ((22.8 * cbrt(x) - 1e3) * x + 3) / (x * x / 2.0);
    double term3 = x * pow((10 + x), (2 / x));
    y = term1 + term2 - term3 - 1.01;

    printf("%.1lf\n", y);
    return 0;
}
