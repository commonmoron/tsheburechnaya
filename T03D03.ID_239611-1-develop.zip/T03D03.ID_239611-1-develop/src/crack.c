#include <stdio.h>

int main() {
    float x, y;

    if (scanf("%f %f", &x, &y) != 2) {
        printf("n/a\n");
        return 1;
    }

    float distance_squared = x * x + y * y;

    if (distance_squared < 25.0) {
        printf("GOTCHA\n");
    } else {
        printf("MISS\n");
    }

    return 0;
}
